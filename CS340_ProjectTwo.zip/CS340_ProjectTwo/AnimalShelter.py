from pymongo import MongoClient

class AnimalShelter(object):
    """ CRUD operations for the AAC Animal collection. """

    def __init__(self, username, password, host='localhost', port=27017,
                 db='aac', collection='animals'):

        uri = f"mongodb://{username}:{password}@{host}:{port}/{db}"
        self.client = MongoClient(uri)
        self.database = self.client[db]
        self.collection = self.database[collection]

    def create(self, data: dict) -> bool:
        if not data or not isinstance(data, dict):
            return False
        result = self.collection.insert_one(data)
        return result.acknowledged

    def read(self, query: dict = None):
        if query is None:
            query = {}
        cursor = self.collection.find(query)
        return list(cursor)

    def update(self, query: dict, update_fields: dict) -> int:
        if not query or not update_fields:
            return 0
        result = self.collection.update_many(query, {"$set": update_fields})
        return result.modified_count

    def delete(self, query: dict) -> int:
        if not query:
            return 0
        result = self.collection.delete_many(query)
        return result.deleted_count
