from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter:
    """
    CRUD operations for the AAC 'animals' collection in MongoDB.
    """

    def __init__(self, username: str, password: str):
        """
        Initialize the MongoDB client and select the database and collection.
        """
        try:
            # IMPORTANT: user 'aacuser' is stored in the 'admin' database
            self.client = MongoClient(
                "mongodb://localhost:27017/",
                username=username,
                password=password,
                authSource="admin"   # <-- THIS MUST BE 'admin'
            )

            # Work with the aac database and animals collection
            self.database = self.client["aac"]
            self.collection = self.database["animals"]

        except PyMongoError as e:
            raise Exception(f"Could not connect to MongoDB: {e}")

    # ---------- C: CREATE ----------
    def create(self, data: dict) -> bool:
        """
        Insert a document into the animals collection.

        :param data: Dictionary document to insert.
        :return: True if insert was successful, otherwise False.
        """
        if data is None or not isinstance(data, dict) or len(data) == 0:
            return False

        try:
            result = self.collection.insert_one(data)
            return result.inserted_id is not None
        except PyMongoError as e:
            # Temporary debug print – fine to leave or remove later
            print("Create error:", e)
            return False

    # ---------- R: READ ----------
    def read(self, query: dict):
        """
        Query for documents from the animals collection.

        :param query: MongoDB query dictionary.
        :return: Cursor of matching documents.
        """
        try:
            if query is None:
                query = {}
            return self.collection.find(query)
        except PyMongoError as e:
            raise Exception(f"Error reading from MongoDB: {e}")
